<?php
   session_start();
   ob_start();
   include_once("include/db_conx.php");
   require( 'include/flash.php' );

   if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] == true){
   }else{
      if(isset($_POST["signup"])){
         $u = (isset($_POST["username"])) ? mysql_real_escape_string($_POST["username"]) : NULL;
         $e = (isset($_POST["email"])) ? mysql_real_escape_string($_POST["email"]) : NULL;
         $p = (isset($_POST["password"])) ? mysql_real_escape_string($_POST["password"]) : NULL;
         $pc = (isset($_POST["password_confirmation"])) ? mysql_real_escape_string($_POST["password_confirmation"]) : NULL;
         $warn = "";
         if(!$u){
            flash( 'warning_class', 'Username field cannot be left blank', 'error' );
         }
         if(!$e){
            flash( 'warning_class', 'E-Mail field cannot be left blank', 'error' );
         }
         if(!$p){
            flash( 'warning_class', 'Password field cannot be left blank', 'error' );
         } 
         if(!$pc){
               flash( 'warning_class', 'Please Confirm your password', 'error' );
         }
         if ($p != $pc) {
               flash( 'warning_class', 'Password doen not match with the confirmed password', 'error' );
         }
         if($u && $e && $p && $pc && $p == $pc){
            $sql = "INSERT INTO members(email,username,password,verified) VALUES ('$e', '$u', '$p', '1')";
            $qry = mysqli_query($db_conx, $sql);
            if($qry){
               flash( 'success_message', 'You are successfully registered');
            }
         }
      }
      if(isset($_POST["login"])){
         $e = (isset($_POST["email"])) ? mysql_real_escape_string($_POST["email"]) : NULL;
         $p = (isset($_POST["password"])) ? mysql_real_escape_string($_POST["password"]) : NULL;
         if(!$e){
            flash( 'warning_class', 'Please Enter your E-Mail', 'error' );
         }
         if(!$p){
            flash( 'warning_class', 'Please Enter your Password', 'error' );
         }
         if($e && $p){
            $sql = "SELECT * FROM members where email = '$e' AND password = '$p' LIMIT 1";
            $query = mysqli_query($db_conx,$sql);
            if(!$query){
               $er = 'Could not run query: ' . mysqli_error($db_conx);
                flash( 'warning_class', $er, 'error' );
            }
            if(mysqli_num_rows($query) > 0){
               $row = mysqli_fetch_row($query);
               if(!$row){
                  $er = 'Could not run query: ' . mysqli_error($db_conx);
                  flash( 'warning_class', $er, 'error' );
               }
               $_SESSION["loggedin"] = true;
               $_SESSION["id"] = $row[0];
               $_SESSION["email"] = $row[1];
               $_SESSION["username"] = $row[2];
               $_SESSION["avatar"] = $row[7];
               flash( 'success_message', 'You are successfully Logged in');
            }else{
               flash( 'warning_class', "Your username or password is incorrect", 'error' );
            }
         }
      }
   }

   
?>

<?php
   include_once("include/header.php");
?>



 	<div class="banner">
		<div class="banner-section">
			<h1>Find Teachers & Hire Them</h1>
			<h3>Need To Grasp The Concepts? Hire A Teacher Here</h3>
			<form class="banner-form" action="search.php" method="GET">
				<div>
					<input type="text" placeholder="I want: " name="search">
					<button><i class="fa fa-search"></i></button>
				</div>
			</form>
			<h3>OR</h3>
         <?php
            if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] == true){
               echo '<a href="newgig.php"><button class="btn btn-success banner-ican">Start Your Own Class</button></a>';
            }else{
               echo '<button class="btn btn-success banner-ican" data-toggle="modal" data-target="#signup">Start Your Own Class</button>';
            }
         ?>
		</div>
	</div>
	<div class="content">
		<div class="content-header">
			<div class="content-header-container row">
				<div class="col-sm-4 chc-trend">
					<ul>
					</ul>
				</div>
				<div class="col-sm-4 chc-metro">
					
				</div>
				<div class="col-sm-4 chc-filter">
					<ul>
						<li>
							<div class="icon1"></div>
						</li>
						<li>
							<div class="icon2"></div>
						</li>
						<li>
							<div class="icon3"></div>
						</li>
						<li>
							<div class="icon4"></div>
						</li>
						<li>
							<div class="icon5"></div>
						</li>
						<li>
							<div class="icon6"></div>
						</li>
					</ul>
				</div>
			</div>
		</div>
		<div class="content_middle">
   	  <div class="container">
   	    <div class="content_middle_box">
          <div class="top_grid">
   			<div class="col-md-3">
   			  <div class="grid1">
   				<a href="search.php?cat=5"><div class="view view-first">
                  
                     <div class="index_img"><img src="postupload/ne8fn7z77vlg0tndtoepyjrhy8yjpnpv8vwtgox53m8o0vtf24.jpg" class="img-responsive" alt=""/></div>
   			      
                      <div class="mask">
                        <div class="info"><i class="search"> </i>Show More</div>
                        <ul class="mask_img">
                        	<li class="star"><img src="img/star.png" alt=""/></li>
                        	<li class="set"><img src="img/set.png" alt=""/></li>
                        	<div class="clearfix"> </div>
                        </ul>
                       </div>
                   </div>
               
                   <i class="home"></i>
   				</a> 
                <div class="inner_wrap">
   				 	<h3>Learn Java From Masters</h3>
   				 	<ul class="star1">
   				 	  <h4 class="green">Java</h4>
   				 	  <li><a href="#"> <img src="img/star1.png" alt="">(3)</a></li>
   				 	</ul>
   				 </div>
   			   </div>
   			</div>
   			<div class="col-md-3">
   			  <div class="grid1">
               <a href="search.php?cat=11">
   				<div class="view view-first">
                  <div class="index_img1"><img src="img/chemistry.jpg" class="img-responsive" alt=""/></div>
   				     <div class="mask">
                        <div class="info"><i class="search"> </i> Show More</div>
                        <ul class="mask_img">
                        	<li class="star"><img src="img/star.png" alt=""/></li>
                        	<li class="set"><img src="img/set.png" alt=""/></li>
                        	<div class="clearfix"> </div>
                        </ul>
                      </div>
                  </div> 
                 <i class="home1"> </i>
              </a>
   				 <div class="inner_wrap">
   				 	<h3>Learn Chemistry From Lab Geeks</h3>
   				 	<ul class="star1">
   				 	  <h4 class="yellow">Chemestry</h4>
   				 	  <li><a href="#"> <img src="img/star2.png" alt="">(4)</a></li>
   				 	</ul>
   				 </div>
   			   </div>
   			</div>
   			<div class="col-md-3">
   			  <div class="grid1">
               <a href="search.php?cat=2">
   				<div class="view view-first">
                  <div class="index_img2"><img src="img/math.jpg" class="img-responsive" alt=""/></div>
   				     <div class="mask">
                        <div class="info"><i class="search"> </i> Show More</div>
                        <ul class="mask_img">
                        	<li class="star"><img src="img/star.png" alt=""/></li>
                        	<li class="set"><img src="img/set.png" alt=""/></li>
                        	<div class="clearfix"> </div>
                        </ul>
                      </div>
                  </div> 
                 <i class="home2"> </i></a>
   				 <div class="inner_wrap">
   				 	<h3>Maths Can Be Fun Here</h3>
   				 	<ul class="star1">
   				 	  <h4 class="blue">Maths</h4>
   				 	  <li><a href="#"> <img src="img/star2.png" alt="">(6)</a></li>
   				 	</ul>
   				 </div>
   			   </div>
   			</div>
   			<div class="col-md-3">
   			  <div class="grid1">
               <a href="search.php?cat=12">
   				<div class="view view-first">
                  <div class="index_img"><img src="img/logoDBMS.jpg" class="img-responsive" alt=""/></div>
   			          <div class="mask">
                      <div class="info"><i class="search"> </i> Show More</div>
                        <ul class="mask_img">
                        	<li class="star"><img src="img/star.png" alt=""/></li>
                        	<li class="set"><img src="img/set.png" alt=""/></li>
                        	<div class="clearfix"> </div>
                        </ul>
                      </div>
                  </div> 
                  <i class="home"></i>
               </a>
   				  <div class="inner_wrap">
   				 	<h3>Handle DBMS Like A Pro</h3>
   				 	<ul class="star1">
   				 	  <h4 class="green">DBMS</h4>
   				 	  <li><a href="#"> <img src="img/star1.png" alt="">(2)</a></li>
   				 	</ul>
   				  </div>
   			   </div>
   			</div>
   			<div class="clearfix"> </div>
   		</div>
   	    <div class="middle_grid wow fadeInUp" data-wow-delay="0.4s">
   			<div class="col-md-6">
   			   <div class="grid1">
                  <a href="search.php?cat=9">
   			     <div class="index_img"><img src="img/biologybanner.jpg" class="img-responsive" alt=""/></div>
   				  <i class="m_home"> </i>
                  <ul class="vision">
                  	 <li>Biology Classes</li>
                  	 <li class="desc"><a href="#"> <img src="img/star1.png" alt="">(5)</a></li>
                  </ul>
   				  <div class="inner_wrap1">
   				 	<ul class="item_module">
   				 	 	<li class="module_left"><img src="img/m1.jpg" class="img-responsive" alt=""/></li>
   				 	 	<li class="module_right">
   				 	 		<img src="img/m_star.png" class="img-responsive" alt=""/>
   				 	 		<h5>Biology</h5>
   				 	 		<p>Biology is a natural science concerned with the study of life and living organisms, including their structure, function, growth, evolution, distribution, and taxonomy</p>
   				 	 		<a href="#" class="content_btn">....read more</a>
   				 	 	</li>
   				 	 	<div class="clearfix"> </div>
   				 	 </ul>
   				  </div>
               </a>
   			   </div>
   			</div>
   			<div class="col-md-6">
   			   <div class="grid1">
                  <a href="search.php?cat=4">
   			     <div class="index_img1"><img src="img/c++.jpg" class="img-responsive" alt=""/></div>
   				  <i class="m_home1"> </i>
                  <ul class="vision">
                  	 <li>C ++</li>
                  	 <li class="desc"><a href="#"> <img src="img/star2.png" alt="">(1)</a></li>
                  </ul>
   				  <div class="inner_wrap1">
   				 	<ul class="item_module">
   				 	 	<li class="module_left"><img src="img/m2.jpg" class="img-responsive" alt=""/></li>
   				 	 	<li class="module_right">
   				 	 		<img src="img/m_star1.png" class="img-responsive" alt=""/>
   				 	 		<h5>C++ Language</h5>
   				 	 		<p>C++ is a general-purpose programming language. It has imperative, object-oriented and generic programming features, while also providing the facilities for low-level memory manipulation.</p>
   				 	 		<a href="#" class="content_btn">....read more</a>
   				 	 	</li>
   				 	 	<div class="clearfix"> </div>
   				 	 </ul>
   				  </div>
               </a>
   			   </div>
   			</div>
   			<div class="clearfix"> </div>
   		</div>
   			<div class="clearfix"> </div>
   		</div>
   		<div class="bottom_grid wow bounce" data-wow-delay="0.4s">
   		  <div class="col-md-6">
   			   <div class="grid1">
                  <a href="search.php?cat=7">
   			     <div class="index_img1"><img src="img/python.jpg" class="img-responsive" alt=""/></div>
   				  <i class="m_home1"> </i>
                  <ul class="vision">
                  	 <li>Python Programming</li>
                  	 <li class="desc"><a href="#"> <img src="img/star2.png" alt="">(236)</a></li>
                  </ul>
   				  <div class="inner_wrap1">
   				 	<ul class="item_module">
   				 	 	<li class="module_left"><img src="img/m2.jpg" class="img-responsive" alt=""/></li>
   				 	 	<li class="module_right">
   				 	 		<img src="img/m_star.png" class="img-responsive" alt=""/>
   				 	 		<h5>Python</h5>
   				 	 		<p>Python is a widely used general-purpose, high-level programming language.Its design philosophy emphasizes code readability.</p>
   				 	 		<a href="#" class="content_btn">....read more</a>
   				 	 	</li>
   				 	 	<div class="clearfix"> </div>
   				 	 </ul>
   				  </div></a>
   			   </div>
   			</div>
   			<div class="col-md-3">
   			  <div class="grid1">
               <a href="search.php?cat=10">
   				<div class="view view-first">
                  <div class="index_img"><img src="img/physics.jpg" class="img-responsive" alt=""/></div>
   			          <div class="mask">
                      <div class="info"><i class="search"> </i> Show More</div>
                        <ul class="mask_img">
                        	<li class="star"><img src="img/star.png" alt=""/></li>
                        	<li class="set"><img src="img/set.png" alt=""/></li>
                        	<div class="clearfix"> </div>
                        </ul>
                      </div>
                  </div> 
                  <i class="b_home"></i>
   				  <div class="inner_wrap2">
   				 	<h3>Learn The Laws Of Physics</h3>
   				 	<ul class="star1">
   				 	  <h4 class="green">Physics</h4>
   				 	  <li><a href="#"> <img src="img/star1.png" alt="">(6)</a></li>
   				 	</ul>
   				  </div>
   			   </div>
   			</div>
   			<div class="col-md-3">
   			  <div class="grid1">
                  <a href="search.php?cat=8">
   				<div class="view view-first">
                  <div class="index_img1"><img src="img/csharp.jpg" class="img-responsive" alt=""/></div>
   				     <div class="mask">
                        <div class="info"><i class="search"> </i> Show More</div>
                        <ul class="mask_img">
                        	<li class="star"><img src="img/star.png" alt=""/></li>
                        	<li class="set"><img src="img/set.png" alt=""/></li>
                        	<div class="clearfix"> </div>
                        </ul>
                      </div>
                  </div> 
                 <i class="b_home1"> </i></a>
   				 <div class="inner_wrap2">
   				 	<h3>Be A Professional C# Developer</h3>
   				 	<ul class="star1">
   				 	  <h4 class="yellow">C# Language</h4>
   				 	  <li><a href="#"> <img src="img/star2.png" alt="">(5)</a></li>
   				 	</ul>
   				 </div>
   			   </div>
   			</div>
   			<div class="clearfix"></div>
   			</div>
   		  </div>
   		  <div class="offering">
   		  	  <h2>What can Whiteboard offer to you ?</h2>
   		  	  <h3>Try us and find it out.</h3>
   		  	  <ul class="icons wow fadeInUp" data-wow-delay="0.4s">
   		  	  	 <li><i class="icon1"> </i><span class="one"> </span></li>
   		  	  	 <li><i class="icon2"> </i><span class="two"> </span></li>
   		  	  	 <li><i class="icon3"> </i><span class="three"> </span></li>
   		  	  	 <li><i class="icon4"> </i><span class="four"> </span></li>
   		  	  	 <li><i class="icon5"> </i></li>
   		  	  </ul>
   		  	  <div class="real">
   		  	  	<h4>Reality</h4>
   		  	  	<div class="col-sm-6">
   		  	  	  <ul class="service_grid">
   	   				<i class="s1"> </i>
   	   				 <li class="desc1 wow fadeInRight" data-wow-delay="0.4s">
   	   				   <p>Whiteboard is an opensource project that can be used in your own websites. This project is developed by a student of Arya College, Ludhiana. The website above is only a demo app on how a whiteboard can be used in real life.</p>
   	   				 </li>
   	   				 <div class="clearfix"> </div>
   	   			   </ul>
   	   			 </div>
   	   			 <div class="col-sm-6">
   		  	  	  <ul class="service_grid">
   	   				<i class="s2"> </i>
   	   				 <li class="desc1 wow fadeInRight" data-wow-delay="0.4s">
   	   				   <p>Whiteboard can be used in many difference occaions. The main vision while creating the project was to create something that a team can use in a collaborative manner. That means a team can draw or pain and everything they draw will automatically be updated on the other clients connected to same canvas.</p>
   	   				 </li>
   	   				 <div class="clearfix"> </div>
   	   			   </ul>
   	   			 </div>
   	   			 <div class="clearfix"> </div>
   	   			 </div>
   		  	  </div>
   		  </div>
   	  </div>
	</div>

   <?php include_once("include/logsign.php"); ?>


<script>
	jQuery(document).ready(function($) {
		$('.metro-drop').click(function(event) {
			$(this).children('ul').toggleClass('hidden');
		});
	});
</script>
</body>
</html>